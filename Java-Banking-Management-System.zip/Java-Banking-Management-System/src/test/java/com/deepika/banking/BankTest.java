package com.deepika.banking;

import org.junit.jupiter.api.Test;
import java.math.BigDecimal;
import static org.junit.jupiter.api.Assertions.*;

class BankTest {
    @Test
    void depositIncreasesBalanceAndAddsHistory() {
        Bank bank = new Bank();
        BankAccount account = bank.createSavingsAccount("Deepika", new BigDecimal("1000"));
        account.deposit(new BigDecimal("250"));
        assertEquals(new BigDecimal("1250"), account.getBalance());
        assertEquals(2, account.getTransactionHistory().size());
    }

    @Test
    void savingsAccountMustKeepMinimumBalance() {
        Bank bank = new Bank();
        BankAccount account = bank.createSavingsAccount("Deepika", new BigDecimal("1000"));
        assertThrows(InsufficientFundsException.class,
                () -> account.withdraw(new BigDecimal("600")));
        assertEquals(new BigDecimal("1000"), account.getBalance());
    }

    @Test
    void currentAccountCanUseOverdraft() {
        Bank bank = new Bank();
        BankAccount account = bank.createCurrentAccount("Deepika",
                new BigDecimal("100"), new BigDecimal("200"));
        account.withdraw(new BigDecimal("250"));
        assertEquals(new BigDecimal("-150"), account.getBalance());
    }

    @Test
    void rejectsZeroOrNegativeDeposit() {
        Bank bank = new Bank();
        BankAccount account = bank.createSavingsAccount("Deepika", new BigDecimal("500"));
        assertThrows(IllegalArgumentException.class, () -> account.deposit(BigDecimal.ZERO));
    }
}
