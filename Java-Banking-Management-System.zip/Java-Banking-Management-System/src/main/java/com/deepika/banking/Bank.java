package com.deepika.banking;

import java.math.BigDecimal;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;

public class Bank {
    private final Map<String, BankAccount> accounts = new LinkedHashMap<>();
    private final AtomicLong sequence = new AtomicLong(1001);

    public BankAccount createSavingsAccount(String holder, BigDecimal openingBalance) {
        String number = nextAccountNumber();
        BankAccount account = new SavingsAccount(number, holder, openingBalance);
        accounts.put(number, account);
        return account;
    }

    public BankAccount createCurrentAccount(String holder, BigDecimal openingBalance, BigDecimal overdraftLimit) {
        String number = nextAccountNumber();
        BankAccount account = new CurrentAccount(number, holder, openingBalance, overdraftLimit);
        accounts.put(number, account);
        return account;
    }

    public BankAccount findAccount(String accountNumber) {
        BankAccount account = accounts.get(accountNumber);
        if (account == null) throw new IllegalArgumentException("Account not found: " + accountNumber);
        return account;
    }

    public Collection<BankAccount> getAllAccounts() {
        return java.util.Collections.unmodifiableCollection(accounts.values());
    }

    private String nextAccountNumber() {
        return "ACC" + sequence.getAndIncrement();
    }
}
