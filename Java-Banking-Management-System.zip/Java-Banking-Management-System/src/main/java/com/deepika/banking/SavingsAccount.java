package com.deepika.banking;

import java.math.BigDecimal;

public class SavingsAccount extends BankAccount {
    private static final BigDecimal MINIMUM_BALANCE = new BigDecimal("500.00");

    public SavingsAccount(String accountNumber, String accountHolder, BigDecimal openingBalance) {
        super(accountNumber, accountHolder, openingBalance);
        if (openingBalance.compareTo(MINIMUM_BALANCE) < 0) {
            throw new IllegalArgumentException("Savings account requires an opening balance of at least 500.00.");
        }
    }

    @Override
    public void withdraw(BigDecimal amount) {
        validatePositive(amount);
        if (getBalance().subtract(amount).compareTo(MINIMUM_BALANCE) < 0) {
            throw new InsufficientFundsException("Withdrawal denied: savings account must maintain 500.00 minimum balance.");
        }
        super.withdraw(amount);
    }

    @Override public String getAccountType() { return "Savings"; }
}
