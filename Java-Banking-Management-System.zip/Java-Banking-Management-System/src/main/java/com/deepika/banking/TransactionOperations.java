package com.deepika.banking;

import java.math.BigDecimal;

public interface TransactionOperations {
    void deposit(BigDecimal amount);
    void withdraw(BigDecimal amount);
    BigDecimal getBalance();
}
