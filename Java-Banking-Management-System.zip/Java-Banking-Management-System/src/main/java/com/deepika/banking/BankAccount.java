package com.deepika.banking;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public abstract class BankAccount implements TransactionOperations {
    private final String accountNumber;
    private final String accountHolder;
    private BigDecimal balance;
    private final List<Transaction> transactions = new ArrayList<>();

    protected BankAccount(String accountNumber, String accountHolder, BigDecimal openingBalance) {
        if (accountHolder == null || accountHolder.isBlank()) {
            throw new IllegalArgumentException("Account holder name cannot be empty.");
        }
        validatePositive(openingBalance);
        this.accountNumber = accountNumber;
        this.accountHolder = accountHolder.trim();
        this.balance = openingBalance;
        if (openingBalance.compareTo(BigDecimal.ZERO) > 0) {
            transactions.add(new Transaction(Transaction.Type.DEPOSIT, openingBalance, balance));
        }
    }

    public String getAccountNumber() { return accountNumber; }
    public String getAccountHolder() { return accountHolder; }
    @Override public BigDecimal getBalance() { return balance; }
    public abstract String getAccountType();

    @Override
    public void deposit(BigDecimal amount) {
        validatePositive(amount);
        balance = balance.add(amount);
        transactions.add(new Transaction(Transaction.Type.DEPOSIT, amount, balance));
    }

    @Override
    public void withdraw(BigDecimal amount) {
        validatePositive(amount);
        if (balance.compareTo(amount) < 0) {
            throw new InsufficientFundsException("Insufficient balance.");
        }
        completeWithdrawal(amount);
    }

    protected void completeWithdrawal(BigDecimal amount) {
        balance = balance.subtract(amount);
        transactions.add(new Transaction(Transaction.Type.WITHDRAWAL, amount, balance));
    }

    protected static void validatePositive(BigDecimal amount) {
        if (amount == null || amount.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("Amount must be greater than zero.");
        }
    }

    public List<Transaction> getTransactionHistory() {
        return Collections.unmodifiableList(transactions);
    }
}
