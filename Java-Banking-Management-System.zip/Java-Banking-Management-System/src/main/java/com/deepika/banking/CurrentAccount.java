package com.deepika.banking;

import java.math.BigDecimal;

public class CurrentAccount extends BankAccount {
    private final BigDecimal overdraftLimit;

    public CurrentAccount(String accountNumber, String accountHolder,
                          BigDecimal openingBalance, BigDecimal overdraftLimit) {
        super(accountNumber, accountHolder, openingBalance);
        if (overdraftLimit == null || overdraftLimit.compareTo(BigDecimal.ZERO) < 0) {
            throw new IllegalArgumentException("Overdraft limit cannot be negative.");
        }
        this.overdraftLimit = overdraftLimit;
    }

    public BigDecimal getOverdraftLimit() { return overdraftLimit; }

    @Override
    public void withdraw(BigDecimal amount) {
        validatePositive(amount);
        if (getBalance().subtract(amount).compareTo(overdraftLimit.negate()) < 0) {
            throw new InsufficientFundsException("Withdrawal denied: overdraft limit exceeded.");
        }
        // The base helper records the withdrawal without applying the standard
        // non-overdraft balance check; the overdraft rule was checked above.
        completeWithdrawal(amount);
    }

    @Override public String getAccountType() { return "Current"; }
}
