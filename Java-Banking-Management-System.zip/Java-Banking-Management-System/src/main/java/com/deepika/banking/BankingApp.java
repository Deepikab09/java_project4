package com.deepika.banking;

import java.math.BigDecimal;
import java.util.Scanner;

public class BankingApp {
    private final Bank bank = new Bank();
    private final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        new BankingApp().run();
    }

    private void run() {
        System.out.println("================================");
        System.out.println("   JAVA BANKING MANAGEMENT");
        System.out.println("================================");
        boolean running = true;
        while (running) {
            printMenu();
            String choice = scanner.nextLine().trim();
            try {
                switch (choice) {
                    case "1" -> createAccount();
                    case "2" -> deposit();
                    case "3" -> withdraw();
                    case "4" -> showBalance();
                    case "5" -> showHistory();
                    case "6" -> listAccounts();
                    case "0" -> running = false;
                    default -> System.out.println("Please select a valid menu option.");
                }
            } catch (RuntimeException ex) {
                System.out.println("Error: " + ex.getMessage());
            }
        }
        System.out.println("Thank you for using the Banking Management System.");
    }

    private void printMenu() {
        System.out.println("\n1. Create account\n2. Deposit\n3. Withdraw\n4. Balance enquiry"
                + "\n5. Transaction history\n6. List accounts\n0. Exit");
        System.out.print("Enter choice: ");
    }

    private void createAccount() {
        System.out.print("Account holder name: ");
        String name = scanner.nextLine();
        System.out.print("Account type (1-Savings, 2-Current): ");
        String type = scanner.nextLine().trim();
        System.out.print("Opening balance: ");
        BigDecimal opening = readMoney();
        BankAccount account;
        if ("1".equals(type)) {
            account = bank.createSavingsAccount(name, opening);
        } else if ("2".equals(type)) {
            System.out.print("Overdraft limit: ");
            account = bank.createCurrentAccount(name, opening, readMoney());
        } else {
            throw new IllegalArgumentException("Choose 1 for Savings or 2 for Current.");
        }
        System.out.println("Account created successfully. Account number: " + account.getAccountNumber());
    }

    private void deposit() {
        BankAccount account = getAccountFromInput();
        System.out.print("Deposit amount: ");
        account.deposit(readMoney());
        System.out.println("Deposit successful. New balance: " + account.getBalance());
    }

    private void withdraw() {
        BankAccount account = getAccountFromInput();
        System.out.print("Withdrawal amount: ");
        account.withdraw(readMoney());
        System.out.println("Withdrawal successful. New balance: " + account.getBalance());
    }

    private void showBalance() {
        BankAccount account = getAccountFromInput();
        System.out.println("Account: " + account.getAccountNumber() + " | Holder: "
                + account.getAccountHolder() + " | Type: " + account.getAccountType()
                + " | Balance: " + account.getBalance());
    }

    private void showHistory() {
        BankAccount account = getAccountFromInput();
        System.out.println("\nTransaction history for " + account.getAccountNumber());
        if (account.getTransactionHistory().isEmpty()) System.out.println("No transactions found.");
        account.getTransactionHistory().forEach(System.out::println);
    }

    private void listAccounts() {
        if (bank.getAllAccounts().isEmpty()) {
            System.out.println("No accounts have been created.");
            return;
        }
        bank.getAllAccounts().forEach(a -> System.out.println(a.getAccountNumber() + " | "
                + a.getAccountHolder() + " | " + a.getAccountType() + " | " + a.getBalance()));
    }

    private BankAccount getAccountFromInput() {
        System.out.print("Enter account number: ");
        return bank.findAccount(scanner.nextLine().trim());
    }

    private BigDecimal readMoney() {
        try {
            return new BigDecimal(scanner.nextLine().trim());
        } catch (NumberFormatException ex) {
            throw new IllegalArgumentException("Enter a valid numeric amount.");
        }
    }
}
