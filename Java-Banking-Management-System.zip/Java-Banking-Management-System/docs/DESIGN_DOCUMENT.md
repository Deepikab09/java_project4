# Design Document — Java Banking Management System

## 1. Introduction
The Java Banking Management System is a menu-driven console application for basic account management. It supports savings and current accounts, deposits, withdrawals, balance enquiries and transaction history.

## 2. Objectives
- Apply object-oriented programming principles in Java.
- Keep account data protected through encapsulation.
- Reuse common account behavior through an abstract parent class.
- Demonstrate runtime polymorphism through overridden withdrawal behavior.
- Maintain a transaction record after each successful operation.

## 3. Scope and assumptions
The project is an educational prototype. Data is stored in memory and is cleared when the application exits. It does not connect to a real bank, process payments, authenticate customers or store sensitive financial information.

## 4. Main classes
- **Bank:** creates accounts, generates account numbers and finds accounts.
- **BankAccount:** abstract base class containing common account details, balance and transaction history.
- **SavingsAccount:** enforces a minimum balance of 500.00.
- **CurrentAccount:** permits withdrawals up to a configured overdraft limit.
- **Transaction:** records transaction type, amount, resulting balance and timestamp.
- **TransactionOperations:** interface defining deposit, withdraw and balance operations.
- **BankingApp:** handles console input and displays the menu.
- **InsufficientFundsException:** reports withdrawals that exceed account rules.

## 5. Functional requirements
1. Create a savings or current account.
2. Generate a unique account number for each account in the running session.
3. Deposit a positive amount.
4. Withdraw a positive amount subject to account rules.
5. Display the current balance.
6. Display transaction history.
7. List all accounts created during the session.

## 6. Validation and business rules
- Account holder name cannot be blank.
- Monetary values must be greater than zero for deposits and withdrawals.
- Savings accounts require an opening balance of at least 500.00 and must retain at least 500.00 after withdrawal.
- Current accounts may go below zero, but not below the negative overdraft limit.
- An unknown account number produces an error message.
- Failed transactions do not change the account balance or transaction history.

## 7. OOP implementation
- **Abstraction:** `BankAccount` is abstract and exposes common account behavior.
- **Encapsulation:** fields are private; callers use methods to read or change account state.
- **Inheritance:** savings and current accounts extend `BankAccount`.
- **Polymorphism:** a `BankAccount` reference can point to either subtype; Java dispatches the overridden `withdraw()` method at runtime.
- **Interface:** `TransactionOperations` defines the operations expected from an account.
- **Overriding:** both account types provide their own `withdraw()` and `getAccountType()` implementations.

## 8. Transaction flow
1. The user selects an operation from the menu.
2. `BankingApp` collects the account number and amount.
3. `Bank` locates the account.
4. The account validates the amount and its account-specific rule.
5. If successful, the balance is updated and a `Transaction` is appended.
6. The application displays the result.

## 9. Testing
JUnit tests cover successful deposits, transaction history, savings minimum-balance enforcement, current-account overdraft and invalid deposit amounts. Run them with `mvn test`.

## 10. Future enhancements
- Persist accounts and transactions in MySQL.
- Add customer login and role-based access.
- Add fund transfers between accounts.
- Generate monthly statements.
- Build a graphical or web interface.
- Add audit logging and stronger security controls.
