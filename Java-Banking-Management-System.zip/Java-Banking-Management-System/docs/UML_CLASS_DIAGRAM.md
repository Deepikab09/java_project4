# UML Class Diagram

The following Mermaid class diagram can be displayed by GitHub in this Markdown file.

```mermaid
classDiagram
    class TransactionOperations {
      <<interface>>
      +deposit(amount)
      +withdraw(amount)
      +getBalance()
    }
    class BankAccount {
      <<abstract>>
      -String accountNumber
      -String accountHolder
      -BigDecimal balance
      -List~Transaction~ transactions
      +deposit(amount)
      +withdraw(amount)
      +getBalance()
      +getAccountType()* String
      +getTransactionHistory()
    }
    class SavingsAccount {
      -BigDecimal MINIMUM_BALANCE
      +withdraw(amount)
      +getAccountType() String
    }
    class CurrentAccount {
      -BigDecimal overdraftLimit
      +withdraw(amount)
      +getAccountType() String
    }
    class Bank {
      -Map accounts
      +createSavingsAccount()
      +createCurrentAccount()
      +findAccount()
    }
    class Transaction {
      -Type type
      -BigDecimal amount
      -BigDecimal balanceAfter
      -LocalDateTime timestamp
    }
    class BankingApp
    class InsufficientFundsException

    TransactionOperations <|.. BankAccount
    BankAccount <|-- SavingsAccount
    BankAccount <|-- CurrentAccount
    Bank o-- BankAccount
    BankAccount o-- Transaction
    BankingApp --> Bank
    BankAccount ..> InsufficientFundsException
```

## Relationship summary
- `SavingsAccount` and `CurrentAccount` inherit common behavior from `BankAccount`.
- `BankAccount` implements the `TransactionOperations` interface.
- `Bank` manages multiple account objects.
- Each account maintains a list of its transactions.
- `BankingApp` uses `Bank` to perform user-requested operations.
