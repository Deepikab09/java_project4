# Java Banking Management System

A console-based banking application built with Java 17 and object-oriented programming. It demonstrates account creation, deposits, withdrawals, balance enquiries and transaction history.

## Features
- Create savings and current accounts
- Deposit and withdraw money with validation
- Check account balance
- View transaction history with timestamps
- Encapsulated account data and reusable banking services
- Polymorphic account withdrawal rules
- Input validation and clear error messages

## OOP concepts demonstrated
| Concept | Implementation |
|---|---|
| Class and object | `Bank`, `BankAccount`, `Transaction`, and account objects |
| Encapsulation | Private fields with controlled public methods |
| Constructor | Account and transaction initialization |
| Inheritance | `SavingsAccount` and `CurrentAccount` extend `BankAccount` |
| Abstraction | `BankAccount` is an abstract class |
| Interface | `TransactionOperations` defines banking operations |
| Polymorphism | `BankAccount` references invoke overridden withdrawal rules |
| Method overriding | Account subclasses override `withdraw()` and `getAccountType()` |
| Access modifiers | `private`, `protected`, and `public` are used according to responsibility |

## Requirements
- Java Development Kit (JDK) 17 or later
- Maven 3.8 or later

Check installations:
```bash
java -version
mvn -version
```

## Run the application
```bash
mvn clean compile
mvn exec:java -Dexec.mainClass="com.deepika.banking.BankingApp"
```

If the Maven exec plugin is not configured locally, run:
```bash
mvn clean package
java -cp target/classes com.deepika.banking.BankingApp
```

## Run tests
```bash
mvn test
```

## Sample workflow
1. Choose **Create account** and select Savings or Current.
2. Enter the account holder's name and opening deposit.
3. Use the generated account number for deposits, withdrawals, balance checks and history.
4. Exit to close the application.

The application stores data in memory while it is running. Accounts and transactions are not persisted after the program exits; database storage can be added as a future enhancement.

## Project structure
```text
src/
 ├── main/java/com/deepika/banking/
 │   ├── BankingApp.java
 │   ├── Bank.java
 │   ├── BankAccount.java
 │   ├── SavingsAccount.java
 │   ├── CurrentAccount.java
 │   ├── Transaction.java
 │   ├── TransactionOperations.java
 │   └── InsufficientFundsException.java
 └── test/java/com/deepika/banking/
     └── BankTest.java
docs/
 ├── DESIGN_DOCUMENT.md
 └── UML_CLASS_DIAGRAM.md
```

## Author
Deepika B

## License
This project is provided for educational and academic use.
